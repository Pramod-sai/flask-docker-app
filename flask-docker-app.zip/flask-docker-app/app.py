
import os
from flask import Flask, jsonify, render_template_string
import redis

app = Flask(__name__)

REDIS_HOST = os.getenv("REDIS_HOST", "redis")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
REDIS_DB = int(os.getenv("REDIS_DB", "0"))
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", None)

def get_r():
    return redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB, password=REDIS_PASSWORD, decode_responses=True)

INDEX_HTML = '''
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Flask + Redis | Docker Demo</title>
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; margin: 40px; }
    .card { border: 1px solid #ddd; border-radius: 12px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); max-width: 720px; }
    h1 { margin-top: 0; }
    code { background: #f6f8fa; padding: 2px 6px; border-radius: 6px; }
    .meta { color: #666; font-size: 14px; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .btn { padding: 10px 14px; border-radius: 8px; border: 1px solid #ccc; background: #fff; cursor: pointer; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Flask + Redis (Docker)</h1>
    <p>This demo runs a Flask web app behind Gunicorn and uses Redis for a simple counter.</p>
    <div class="grid">
      <div><strong>Visits:</strong> {{ visits }}</div>
      <div><strong>Redis Host:</strong> {{ redis_host }}</div>
    </div>
    <p class="meta">Try:
      <code>GET /api/ping</code> |
      <code>GET /cache/incr</code> |
      <code>GET /health</code>
    </p>
    <form method="post" action="/cache/incr">
      <button class="btn" type="submit">Increment Counter</button>
    </form>
  </div>
</body>
</html>
'''

@app.route("/")
def index():
    r = get_r()
    visits = r.incr("visits") if r else 0
    return render_template_string(INDEX_HTML, visits=visits, redis_host=REDIS_HOST)

@app.route("/api/ping")
def api_ping():
    return jsonify({"status": "ok", "message": "pong"})

@app.route("/cache/incr", methods=["GET", "POST"])
def cache_incr():
    r = get_r()
    value = r.incr("visits")
    return jsonify({"visits": value})

@app.route("/health")
def health():
    return ("OK", 200)

if __name__ == "__main__":
    # Dev server (not used in container); container uses Gunicorn
    app.run(host="0.0.0.0", port=8000)
