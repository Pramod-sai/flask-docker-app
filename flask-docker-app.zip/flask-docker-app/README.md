# Flask + Redis (Docker) — Professional Demo

A production-style containerized Flask application backed by Redis for a simple visit counter.
Built for local reproducibility and easy CI/CD testing.

## Features
- Flask app served by Gunicorn (prod-ready WSGI)
- Redis-backed counter and health endpoints
- Clean Dockerfile (slim image, non-root user)
- docker-compose for multi-container orchestration
- Makefile shortcuts (build, up, down, logs)
- PDF report and architecture diagram included

## Endpoints
- `GET /` — HTML page with counter
- `GET /api/ping` — health-style JSON ping
- `GET|POST /cache/incr` — increments Redis key `visits`
- `GET /health` — returns `200 OK`

## Run Locally
```bash
docker compose up --build -d
# visit http://localhost:8000
docker compose logs -f
docker compose down -v
```

## Project Structure
```
flask-docker-app/
├─ app.py
├─ requirements.txt
├─ Dockerfile
├─ docker-compose.yml
├─ .env.sample
├─ Makefile
├─ images/
│  ├─ architecture_diagram.png
│  └─ sample_ui.png
└─ docs/
   └─ Flask_Docker_Project_Report.pdf
```

## Notes
- Uses `redis:7-alpine` with AOF persistence and a named volume
- For prod, put secrets into a secure store; `.env.sample` is just a template
- Scale workers via Gunicorn flags or docker-compose replicas
